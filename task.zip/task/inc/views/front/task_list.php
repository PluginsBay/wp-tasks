<?php
	$this->view_inc('front/nav.php');
	$this->view_inc('front/list.php');
?>

