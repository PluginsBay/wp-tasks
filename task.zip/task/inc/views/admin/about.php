<div class="wrap">
	<img src="<?php echo plugins_url('/img/logo.32.png', TASK_ROOT_FILE); ?>" class="icon32" style="background:none"/>
	<h2>About Tasks</h2>
	<p>More info on <a href="http://www.tasks.com" target="_blank">tasks's website</a></p>
</div>